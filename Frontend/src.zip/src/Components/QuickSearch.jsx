import React, { useState } from "react";
import {
  Card,
  Button,
  Row,
  Col,
  Form,
  ListGroup,
  Spinner,
} from "react-bootstrap";
import { useLocations } from "../hooks/useLocation";
import { debounce } from "../utils/transportUtils";
import { useNavigate } from "react-router-dom";

export default function QuickSearch() {
  const [fromQuery, setFromQuery] = useState("");
  const [toQuery, setToQuery] = useState("");
  const [selectedFrom, setSelectedFrom] = useState(null);
  const [selectedTo, setSelectedTo] = useState(null);

  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);

  const navigate = useNavigate();

  const { data: fromResults, isLoading: fromLoading } = useLocations(fromQuery);
  const { data: toResults, isLoading: toLoading } = useLocations(toQuery);

  const debouncedSetFrom = debounce(setFromQuery, 300);
  const debouncedSetTo = debounce(setToQuery, 300);

  const handleSwap = () => {
    const temp = selectedFrom;
    setSelectedFrom(selectedTo);
    setSelectedTo(temp);

    setFromQuery(toQuery);
    setToQuery(fromQuery);
  };

  const handleSearch = () => {
    if (!selectedFrom || !selectedTo) return;

    navigate(
      `/plan?from=${selectedFrom.id}&to=${selectedTo.id}&fromName=${encodeURIComponent(selectedFrom.name)}&toName=${encodeURIComponent(selectedTo.name)}`,
    );
  };

  return (
    <Card className="mb-4">
      <Card.Body className="p-4">
        <h4 className="mb-4 fw-bold">Quick Search</h4>

        <Row className="g-3">
          <Col md={5}>
            <Form.Control
              placeholder="From"
              value={fromQuery}
              onChange={(e) => {
                debouncedSetFrom(e.target.value);
                setShowFromSuggestions(true);
              }}
            />

            {fromLoading && <Spinner size="sm" />}

            {showFromSuggestions && fromResults?.length > 0 && (
              <ListGroup>
                {fromResults.map((loc) => (
                  <ListGroup.Item
                    key={loc.id}
                    action
                    onClick={() => {
                      setSelectedFrom(loc);
                      setFromQuery(loc.name);
                      setShowFromSuggestions(false);
                    }}
                  >
                    {loc.name}
                  </ListGroup.Item>
                ))}
              </ListGroup>
            )}
          </Col>

          <Col md={2} className="d-flex align-items-end justify-content-center">
            <Button variant="outline-primary" onClick={handleSwap}>
              ⇄
            </Button>
          </Col>

          <Col md={5}>
            <Form.Control
              placeholder="To"
              value={toQuery}
              onChange={(e) => {
                debouncedSetTo(e.target.value);
                setShowToSuggestions(true);
              }}
            />

            {toLoading && <Spinner size="sm" />}

            {showToSuggestions && toResults?.length > 0 && (
              <ListGroup>
                {toResults.map((loc) => (
                  <ListGroup.Item
                    key={loc.id}
                    action
                    onClick={() => {
                      setSelectedTo(loc);
                      setToQuery(loc.name);
                      setShowToSuggestions(false);
                    }}
                  >
                    {loc.name}
                  </ListGroup.Item>
                ))}
              </ListGroup>
            )}
          </Col>

          <Col xs={12}>
            <Button
              variant="primary"
              size="lg"
              className="w-100"
              onClick={handleSearch}
            >
              Search Connections
            </Button>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}
