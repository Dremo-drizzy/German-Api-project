import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, Container, Button } from 'react-bootstrap';

function TransNavbar({ darkMode, onToggleTheme }) {


  return (
    <Navbar 
      expand="lg" 
      bg={darkMode ? 'dark' : 'white'} 
      variant={darkMode ? 'dark' : 'light'}
      className="navbar-custom shadow-sm fixed-top"
    >
      <Container fluid>
        <Navbar.Brand as={Link} to="/" className="brand-logo">
          <span className="brand-icon">🚆</span>
          <span className="brand-text">TransitFlow</span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbar-nav" />
        <Navbar.Collapse id="navbar-nav">
          <Nav className="me-auto">
            <Nav.Link 
              as={Link} 
              to="/" 
            >
              Home
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/plan" 
              
            >
              Plan
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/commutes" 
            >
              Commutes
            </Nav.Link>
          </Nav>
          <Button 
            variant={darkMode ? 'outline-light' : 'outline-dark'}
            size="sm"
            onClick={onToggleTheme}
            aria-label="Toggle dark mode"
            className="theme-toggle"
          >
            {darkMode ? '☀️' : '🌙'}
          </Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default TransNavbar;