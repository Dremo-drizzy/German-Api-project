import React from 'react';
import { Link } from 'react-router-dom';
import { Container } from 'react-bootstrap';

function Footer() {
  return (
    <footer className="footer-custom fixed-bottom bg-light text-center py-2">
      <Container fluid>
        <small className="text-muted">
          Powered by{' '}
          <a 
            href="https://transport.rest" 
            target="_blank" 
            rel="noopener noreferrer"
          >
            transport.rest
          </a>
          {' – DB & partners • '}
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noopener noreferrer"
          >
            GitHub
          </a>
          {' • '}
          <Link to="/about">About</Link>
        </small>
      </Container>
    </footer>
  );
}

export default Footer;