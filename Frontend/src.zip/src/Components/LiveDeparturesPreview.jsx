import React, { useState, useEffect } from 'react';
import { Card, ListGroup, Badge, Spinner } from 'react-bootstrap';
import { useDepartures } from '../hooks/useDepartures';
import { useNearbyStops } from '../hooks/useNearbyStops';
import { getUserLocation } from '../utils/transportUtils';
import { formatTime, getDelayMinutes, formatDelay, getProductIcon, getDelayBadgeVariant } from '../utils/transportUtils';

export default function LiveDeparturesPreview() {
  const [stopId, setStopId] = useState('900003200'); 
  const [stopName, setStopName] = useState('Berlin Hbf'); 

  useEffect(() => {
    getUserLocation()
      .then(({ lat, lon }) => {
        useNearbyStops(lat, lon).data?.then((stops) => {
          if (stops?.length > 0) {
            setStopId(stops[0].id);
            setStopName(stops[0].name);
          }
        });
      })
      .catch(() => console.log('No location - using default'));
  }, []);

  const { data, isLoading, error } = useDepartures(stopId, { duration: 60 });

  if (isLoading) return <Spinner animation="border" />;
  if (error) return <div>Error loading departures: {error.message}</div>;

  const departures = data?.departures || [];

  return (
    <Card className="mb-4">
      <Card.Header className="d-flex justify-content-between align-items-center">
        <h5 className="mb-0 fw-bold">Live Departures at {stopName}</h5>
        <span className="text-white" style={{ cursor: 'pointer' }}>View All →</span>
      </Card.Header>
      <Card.Body className="p-0">
        <ListGroup variant="flush">
{departures.map((dep) => {            
            const delay = getDelayMinutes(dep.plannedWhen, dep.when);
            const actualTime = formatTime(dep.when);
            const plannedTime = formatTime(dep.plannedWhen);
            return (
              <ListGroup.Item key={dep.tripId || dep.when} className="d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center gap-3 flex-grow-1">
                  <span style={{ fontSize: '1.5rem' }}>
                    {getProductIcon(dep.line?.product)}
                  </span>
                  <div className="flex-grow-1">
                    <div className="fw-bold">{dep.line?.name || dep.tripId}</div>
                    <div className="text-muted small">{dep.direction}</div>
                  </div>
                </div>
                <div className="text-end">
                  <div className="d-flex align-items-center gap-2">
                    <div>
                      <div className={delay > 0 ? 'text-decoration-line-through text-muted small' : 'fw-semibold'}>
                        {plannedTime}
                      </div>
                      {delay > 0 && (
                        <div className="fw-semibold text-danger small">
                          {actualTime}
                        </div>
                      )}
                    </div>
                    <Badge bg={getDelayBadgeVariant(delay)}>
                      {formatDelay(delay)}
                    </Badge>
                  </div>
                  {dep.platform && (
                    <Badge bg="secondary" className="mt-1">Pl. {dep.platform}</Badge>
                  )}
                </div>
              </ListGroup.Item>
            );
          })}
        </ListGroup>
      </Card.Body>
    </Card>
  );
}