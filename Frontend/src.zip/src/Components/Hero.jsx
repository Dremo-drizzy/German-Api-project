import React from 'react';

export default function Hero({ title, subtitle }) {
  return (
    <div className="hero-section">
      <h1 className="hero-title">{title}</h1>
      <p className="hero-subtitle">{subtitle}</p>
    </div>
  );
}