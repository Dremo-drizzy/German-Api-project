import React, { useState, useEffect } from "react";
import {
  Card,
  Button,
  Row,
  Col,
  Accordion,
  Form,
  ListGroup,
  Badge,
  Spinner,
} from "react-bootstrap";

import { useJourneys } from "../hooks/useJourneys";
import { useLocations } from "../hooks/useLocation";
import { debounce } from "../utils/transportUtils";

import {
  formatTime,
  formatDuration,
  getProductIcon,
  formatDelay,
  getDelayMinutes,
  getDelayBadgeVariant,
} from "../utils/transportUtils";

import { useSearchParams } from "react-router-dom";

export default function PlanJourney() {
  const [searchParams] = useSearchParams();

  const [fromQuery, setFromQuery] = useState("");
  const [toQuery, setToQuery] = useState("");

  const [selectedFrom, setSelectedFrom] = useState(null);
  const [selectedTo, setSelectedTo] = useState(null);

  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);

  const [departure, setDeparture] = useState(new Date().toISOString());
  const [transfers, setTransfers] = useState(3);
  const [accessibility, setAccessibility] = useState(false);

  const [searchTriggered, setSearchTriggered] = useState(0);

  const debouncedSetFrom = debounce(setFromQuery, 300);
  const debouncedSetTo = debounce(setToQuery, 300);

  const { data: fromResults, isLoading: fromLoading } = useLocations(fromQuery);
  const { data: toResults, isLoading: toLoading } = useLocations(toQuery);

  useEffect(() => {
    const fromId = searchParams.get("from");
    const toId = searchParams.get("to");

    const fromName = searchParams.get("fromName");
    const toName = searchParams.get("toName");

    if (fromId && toId) {
      setFromQuery(decodeURIComponent(fromName || ""));
      setToQuery(decodeURIComponent(toName || ""));

      setSelectedFrom({ id: fromId, name: fromName });
      setSelectedTo({ id: toId, name: toName });

      setSearchTriggered((prev) => prev + 1);
    }
  }, []);

  const params = {
    from: selectedFrom?.id || fromQuery,
    to: selectedTo?.id || toQuery,
    departure,
    transfers,
    accessibility,
  };

  const { data, isLoading, error, refetch } = useJourneys(
    params,
    searchTriggered,
  );

  const handleSearch = () => {
    if (!(selectedFrom || fromQuery) || !(selectedTo || toQuery)) return;

    setSearchTriggered((prev) => prev + 1);
    refetch();
  };

  const handleSwap = () => {
    const tempSelected = selectedFrom;
    setSelectedFrom(selectedTo);
    setSelectedTo(tempSelected);

    const tempQuery = fromQuery;
    setFromQuery(toQuery);
    setToQuery(tempQuery);
  };

  if (error) return <div>Error: {error.message}</div>;

  const journeys = data?.journeys || [];

  return (
    <div>
      <h2 className="mb-4 fw-bold">Journey Planner</h2>

      {/* SEARCH CARD */}

      <Card className="mb-4">
        <Card.Body className="p-4">
          <Row className="g-3">
            <Col md={5}>
              <label className="form-label fw-semibold">From</label>

              <Form.Control
                type="text"
                value={fromQuery}
                placeholder="Origin station"
                onChange={(e) => {
                  debouncedSetFrom(e.target.value);
                  setShowFromSuggestions(true);
                }}
              />

              {fromLoading && <Spinner size="sm" />}

              {showFromSuggestions && fromResults?.length > 0 && (
                <ListGroup>
                  {fromResults.map((loc) => (
                    <ListGroup.Item
                      key={loc.id}
                      action
                      onClick={() => {
                        setSelectedFrom(loc);
                        setFromQuery(loc.name);
                        setShowFromSuggestions(false);
                      }}
                    >
                      {loc.name}
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              )}
            </Col>

            <Col
              md={2}
              className="d-flex align-items-end justify-content-center"
            >
              <Button variant="outline-primary" onClick={handleSwap}>
                ⇄
              </Button>
            </Col>

            <Col md={5}>
              <label className="form-label fw-semibold">To</label>

              <Form.Control
                type="text"
                value={toQuery}
                placeholder="Destination station"
                onChange={(e) => {
                  debouncedSetTo(e.target.value);
                  setShowToSuggestions(true);
                }}
              />

              {toLoading && <Spinner size="sm" />}

              {showToSuggestions && toResults?.length > 0 && (
                <ListGroup>
                  {toResults.map((loc) => (
                    <ListGroup.Item
                      key={loc.id}
                      action
                      onClick={() => {
                        setSelectedTo(loc);
                        setToQuery(loc.name);
                        setShowToSuggestions(false);
                      }}
                    >
                      {loc.name}
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              )}
            </Col>

            <Col md={6}>
              <label className="form-label fw-semibold">Departure</label>

              <Form.Control
                type="datetime-local"
                value={departure.slice(0, 16)}
                onChange={(e) =>
                  setDeparture(new Date(e.target.value).toISOString())
                }
              />
            </Col>

            <Col xs={12}>
              <Button
                variant="primary"
                size="lg"
                className="w-100"
                onClick={handleSearch}
              >
                Search Journeys
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* RESULTS */}

      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="fw-bold mb-0">Available Connections</h4>

        <Button
          variant="outline-primary"
          size="sm"
          onClick={() => {
            setSearchTriggered((prev) => prev + 1);
            refetch();
          }}
        >
          Refresh
        </Button>
      </div>

      {isLoading ? (
        <Spinner animation="border" />
      ) : journeys.length === 0 ? (
        <p className="text-muted">No journeys found.</p>
      ) : (
        journeys.map((journey) => (
          <Card key={journey.refreshToken} className="mb-3">
            <Card.Header className="d-flex justify-content-between align-items-center">
              <div>
                <div className="fw-bold">
                  {journey.legs[0]?.origin?.name} →{" "}
                  {journey.legs[journey.legs.length - 1]?.destination?.name}
                </div>

                <div className="text-muted small">
                  {formatTime(journey.legs[0]?.plannedDeparture)} →{" "}
                  {formatTime(
                    journey.legs[journey.legs.length - 1]?.plannedArrival,
                  )}
                </div>
              </div>

              <Badge bg="secondary">{formatDuration(journey.duration)}</Badge>
            </Card.Header>

            <Card.Body>
              <ListGroup variant="flush">
                {journey.legs.map((leg, i) => {
                  const delay = getDelayMinutes(
                    leg.plannedDeparture,
                    leg.departure,
                  );

                  return (
                    <ListGroup.Item key={i}>
                      <div className="d-flex justify-content-between">
                        <div>
                          <div className="fw-bold">
                            {getProductIcon(leg.line?.product)}{" "}
                            {leg.line?.name || leg.tripId}
                          </div>

                          <div className="text-muted small">
                            {leg.origin?.name} → {leg.destination?.name}
                          </div>
                        </div>

                        <div className="text-end">
                          <div>
                            {formatTime(leg.plannedDeparture)} -{" "}
                            {formatTime(leg.plannedArrival)}
                          </div>

                          <Badge bg={getDelayBadgeVariant(delay)}>
                            {formatDelay(delay)}
                          </Badge>
                        </div>
                      </div>
                    </ListGroup.Item>
                  );
                })}
              </ListGroup>
            </Card.Body>
          </Card>
        ))
      )}
    </div>
  );
}
