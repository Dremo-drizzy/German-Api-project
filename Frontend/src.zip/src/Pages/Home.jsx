import React from 'react';
import Hero from '../Components/Hero';
import LiveDeparturesPreview from '../Components/LiveDeparturesPreview';
import QuickSearch from '../Components/QuickSearch';

export default function Home() {
  return (
    <div>
      <Hero 
        title="Welcome to TransConnect"
        subtitle="Your one-stop platform for seamless public transportation planning and real-time updates."
      />
      <QuickSearch/>
      <LiveDeparturesPreview/>
    </div>
  );
}