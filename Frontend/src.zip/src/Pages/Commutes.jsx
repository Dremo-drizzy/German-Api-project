// src/components/Commutes.js

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  Button,
  Row,
  Col,
  Badge,
  Modal,
  Form,
  ListGroup,
  Spinner
} from "react-bootstrap";

import { format } from "date-fns";

import { useLocations } from "../hooks/useLocation";
import { debounce } from "../utils/transportUtils";
import {
  loadFromLocalStorage,
  saveToLocalStorage
} from "../utils/transportUtils";

export default function Commutes() {

  const navigate = useNavigate();

  const [commutes, setCommutes] = useState(
    loadFromLocalStorage("commutes", [])
  );

  const [showModal, setShowModal] = useState(false);

  const [name, setName] = useState("");

  const [fromQuery, setFromQuery] = useState("");
  const [toQuery, setToQuery] = useState("");

  const [selectedFrom, setSelectedFrom] = useState(null);
  const [selectedTo, setSelectedTo] = useState(null);

  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);

  const debouncedSetFrom = debounce(setFromQuery, 300);
  const debouncedSetTo = debounce(setToQuery, 300);

  const { data: fromResults, isLoading: fromLoading } =
    useLocations(fromQuery);

  const { data: toResults, isLoading: toLoading } =
    useLocations(toQuery);

  const handleAddCommute = () => {

    if (!name || !selectedFrom || !selectedTo) return;

    const newCommute = {
      id: Date.now(),
      name,
      from: selectedFrom,
      to: selectedTo,
      createdAt: new Date().toISOString()
    };

    const updated = [...commutes, newCommute];

    setCommutes(updated);

    saveToLocalStorage("commutes", updated);

    setShowModal(false);

    setName("");
    setFromQuery("");
    setToQuery("");
    setSelectedFrom(null);
    setSelectedTo(null);
  };

  const handleDelete = (id) => {

    const updated = commutes.filter(c => c.id !== id);

    setCommutes(updated);

    saveToLocalStorage("commutes", updated);
  };

  const handlePlanJourney = (commute) => {

    navigate(
      `/plan?fromId=${commute.from.id}&fromName=${encodeURIComponent(
        commute.from.name
      )}&toId=${commute.to.id}&toName=${encodeURIComponent(
        commute.to.name
      )}`
    );
  };

  const handleViewDepartures = (commute) => {

    navigate(
      `/departures?stationId=${commute.from.id}&stationName=${encodeURIComponent(
        commute.from.name
      )}`
    );
  };

  return (
    <div>

      <div className="d-flex justify-content-between align-items-center mb-4">

        <h2 className="fw-bold mb-0">
          My Commutes
        </h2>

        <Button
          variant="primary"
          onClick={() => setShowModal(true)}
        >
          ➕ Add Commute
        </Button>

      </div>


      {commutes.length === 0 ? (

        <Card>

          <Card.Body className="text-center p-5">

            <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>
              🚇
            </div>

            <h4 className="fw-bold mb-3">
              No Saved Commutes Yet
            </h4>

            <p className="text-muted mb-4">
              Save your frequent routes for quick access to journey plans and live updates.
            </p>

            <Button
              variant="primary"
              size="lg"
              onClick={() => setShowModal(true)}
            >
              Add Your First Commute
            </Button>

          </Card.Body>

        </Card>

      ) : (

        <Row className="g-3">

          {commutes.map((commute) => (

            <Col md={6} lg={4} key={commute.id}>

              <Card className="h-100">

                <Card.Body>

                  <div className="d-flex justify-content-between align-items-start mb-3">

                    <h5 className="fw-bold mb-0">
                      {commute.name}
                    </h5>

                    <Button
                      variant="link"
                      className="text-danger p-0"
                      onClick={() => handleDelete(commute.id)}
                    >
                      🗑️
                    </Button>

                  </div>

                  <div className="mb-3">

                    <div className="d-flex align-items-center gap-2 mb-2">

                      <Badge bg="primary">From</Badge>

                      <span className="fw-semibold">
                        {commute.from.name}
                      </span>

                    </div>

                    <div className="d-flex align-items-center gap-2">

                      <Badge bg="success">To</Badge>

                      <span className="fw-semibold">
                        {commute.to.name}
                      </span>

                    </div>

                  </div>

                  <div className="d-grid gap-2">

                    <Button
                      variant="primary"
                      onClick={() => handlePlanJourney(commute)}
                    >
                      Plan Journey
                    </Button>

                    <Button
                      variant="outline-primary"
                      onClick={() => handleViewDepartures(commute)}
                    >
                      View Departures
                    </Button>

                  </div>

                </Card.Body>

                <Card.Footer className="text-muted small">

                  Added{" "}
                  {format(
                    new Date(commute.createdAt),
                    "dd/MM/yyyy"
                  )}

                </Card.Footer>

              </Card>

            </Col>

          ))}

        </Row>

      )}


      {/* ADD COMMUTE MODAL */}

      <Modal show={showModal} onHide={() => setShowModal(false)}>

        <Modal.Header closeButton>

          <Modal.Title>
            Add Commute
          </Modal.Title>

        </Modal.Header>

        <Modal.Body>

          <Form.Group className="mb-3">

            <Form.Label>
              Commute Name
            </Form.Label>

            <Form.Control
              value={name}
              placeholder="Home → Work"
              onChange={(e) => setName(e.target.value)}
            />

          </Form.Group>


          {/* FROM */}

          <Form.Group className="mb-3">

            <Form.Label>From</Form.Label>

            <Form.Control
              value={fromQuery}
              placeholder="Origin station"
              onChange={(e) => {
                debouncedSetFrom(e.target.value);
                setShowFromSuggestions(true);
              }}
            />

            {fromLoading && <Spinner size="sm" />}

            {showFromSuggestions && fromResults?.length > 0 && (

              <ListGroup>

                {fromResults.map((loc) => (

                  <ListGroup.Item
                    key={loc.id}
                    action
                    onClick={() => {
                      setSelectedFrom(loc);
                      setFromQuery(loc.name);
                      setShowFromSuggestions(false);
                    }}
                  >

                    {loc.name}

                  </ListGroup.Item>

                ))}

              </ListGroup>

            )}

          </Form.Group>


          {/* TO */}

          <Form.Group>

            <Form.Label>To</Form.Label>

            <Form.Control
              value={toQuery}
              placeholder="Destination station"
              onChange={(e) => {
                debouncedSetTo(e.target.value);
                setShowToSuggestions(true);
              }}
            />

            {toLoading && <Spinner size="sm" />}

            {showToSuggestions && toResults?.length > 0 && (

              <ListGroup>

                {toResults.map((loc) => (

                  <ListGroup.Item
                    key={loc.id}
                    action
                    onClick={() => {
                      setSelectedTo(loc);
                      setToQuery(loc.name);
                      setShowToSuggestions(false);
                    }}
                  >

                    {loc.name}

                  </ListGroup.Item>

                ))}

              </ListGroup>

            )}

          </Form.Group>

        </Modal.Body>

        <Modal.Footer>

          <Button
            variant="secondary"
            onClick={() => setShowModal(false)}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            onClick={handleAddCommute}
          >
            Save Commute
          </Button>

        </Modal.Footer>

      </Modal>

    </div>
  );
}