import Footer from "./Components/Footer"
import { useState } from "react"
import { Route, Routes } from "react-router-dom"
import Home from "./Pages/Home"
import PlanJourney from "./Pages/PlanJourney"
import Commutes from "./Pages/Commutes"
import About from "./Pages/About"
import TransNavbar from "./Components/TransNavbar"
import './App.css';


function App() {
  const [darkMode, setDarkMode] = useState(false);

  const handleToggleTheme = () => {
    setDarkMode(!darkMode);
    document.documentElement.setAttribute('data-bs-theme', !darkMode ? 'dark' : 'light');
  };

  return(
    <>
    <div className="app-wrapper" data-bs-theme={darkMode ? 'dark' : 'light'}></div>
      <TransNavbar darkMode={darkMode} onToggleTheme={handleToggleTheme} />
      <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/plan" element={<PlanJourney />} />
            <Route path="/commutes" element={<Commutes />} />
            <Route path="/about" element={<About />} />
      </Routes>
      <Footer />
    </>
  )
}
export default App
