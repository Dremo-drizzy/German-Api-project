import { format, formatDistanceToNow, parseISO, differenceInMinutes } from 'date-fns';

export const formatTime = (dateString) => {
  if (!dateString) return '--:--';
  try {
    return format(parseISO(dateString), 'HH:mm');
  } catch {
    return '--:--';
  }
};

export const formatRelativeTime = (dateString) => {
  if (!dateString) return '';
  try {
    return formatDistanceToNow(parseISO(dateString), { addSuffix: true });
  } catch {
    return '';
  }
};

export const getDelayMinutes = (scheduled, actual) => {
  if (!scheduled || !actual) return 0;
  try {
    return differenceInMinutes(parseISO(actual), parseISO(scheduled));
  } catch {
    return 0;
  }
};

export const formatDelay = (delayMinutes) => {
  if (delayMinutes === 0) return 'On time';
  if (delayMinutes > 0) return `+${delayMinutes} min`;
  return `${delayMinutes} min`;
};

export const getDelayBadgeVariant = (delayMinutes) => {
  if (delayMinutes <= 0) return 'success';
  if (delayMinutes < 5) return 'warning';
  return 'danger';
};

// Duration
export const formatDuration = (seconds) => {
  if (!seconds) return '';
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
};

// Icons based on API product/line
export const getProductIcon = (product) => {
  if (!product) return '🚇';
  const type = product.type?.toLowerCase() || product.name?.toLowerCase() || '';
  if (type.includes('ice') || type.includes('high_speed')) return '🚄';
  if (type.includes('regional') || type.includes('re')) return '🚆';
  if (type.includes('s-bahn') || type.includes('s')) return '🚈';
  if (type.includes('u-bahn') || type.includes('u')) return '🚇';
  if (type.includes('tram')) return '🚊';
  if (type.includes('bus')) return '🚌';
  if (type.includes('ferry')) return '⛴️';
  return '🚇'; // Default
};

// Distance
export const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export const formatDistance = (km) => {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
};

export const debounce = (func, wait) => {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

// Local storage for favorites/commutes
export const saveToLocalStorage = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('LocalStorage save error:', error);
  }
};

export const loadFromLocalStorage = (key, defaultValue = []) => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error('LocalStorage load error:', error);
    return defaultValue;
  }
};

// Geolocation
export const getUserLocation = () => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({ lat: position.coords.latitude, lon: position.coords.longitude }),
      reject,
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  });
};